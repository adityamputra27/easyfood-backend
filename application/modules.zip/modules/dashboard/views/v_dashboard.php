<?php 
    $this->load->view('layouts/v_header'); 
    $this->load->helper('time_helper');
?>
<section class="content-header">
    <h1>
    Dashboard
    </h1>
    <ol class="breadcrumb">
    <li><a href="#" class="active"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3><?= $totalProduct ?></h3>
                    <p>Total Produk</p>
                </div>
                <div class="icon">
                    <i class="ion ion-bag"></i>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-green">
                <div class="inner">
                    <h3><?= $totalTransaction ?></h3>
                    <p>Total Seluruh Transaksi</p>
                </div>
                <div class="icon">
                    <i class="fa fa-shopping-cart"></i>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-yellow">
                <div class="inner">
                    <h3><?= $totalTransactionToday; ?></h3>
                    <p>Total Transaksi Hari Ini</p>
                </div>
                <div class="icon">
                    <i class="fa fa-arrow-circle-down"></i>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-red">
                <div class="inner">
                    <h3><?= $incomeTransactionToday; ?></h3>
                    <p>Total Pendapatan Hari Ini</p>
                </div>
                <div class="icon">
                    <i class="fa fa-area-chart"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <?php if(count($expiredProducts) > 0): ?>
        <div class="box-body">
            <div class="callout callout-danger">
            <h4><i class="fa fa-bullhorn"></i> Notifikasi!</h4>
                <ul>
                    <?php foreach($expiredProducts as $key => $product): ?>
                        <?php if($product->expired_status == 'ACTIVE') : ?>
                        <li><b>Tanggal kadaluarsa</b> : <?= $product->name ?> | <b> <?= date('d-m-Y', strtotime($product->expired_date)) ?> - <?= $product->expired_month > 0 ? $product->expired_month.' bulan' : '' ?> <?= $product->expired_day > 0 ? $product->expired_day.' hari' : '' ?> lagi!</b></li>
                        <?php endif ?>
                    <?php endforeach ?>
                    <?php foreach($expiredProducts as $key => $product): ?>
                        <?php if($product->expired_status == 'INACTIVE') : ?>
                        <li><?= $product->name ?> | <b> <?= date('d-m-Y', strtotime($product->expired_date)) ?> - sudah kadaluarsa!</b></li>
                        <?php endif ?>
                    <?php endforeach ?>
                </ul>
            </div>
        </div>
        <?php endif ?>
    </div>
    <div class="row">
        <div class="col-md-7 col-12">
            <div class="box">
                <div class="box-header">
                    <h5 class="box-title">Pendapatan Bulan Ini (<?= bulanIndo(date('m')).' '.date('Y') ?>)</h5>
                </div>
                <div class="box-body">
                    <canvas id="myChart"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-5 col-12">
            <div class="box">
                <div class="box-header">
                    <h5 class="box-title">5 Produk Terlaris</h5>
                </div>
                <div class="box-body">
                    <canvas id="myChartPie" width="400"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-7 col-12">
            <div class="box">
                <div class="box-header">
                    <h5 class="box-title">3 Transaksi Terakhir</h5>
                </div>
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table table table-bordered table-hovered table-striped">
                            <tr>
                                <th width="1%">No</th>
                                <th width="17%">Tanggal</th>
                                <th>Nama Produk</th>
                                <th>Status</th>
                                <th width="15%">Total</th>
                            </tr>
                            <?php foreach ($lastTransctions as $key => $value) { ?>
                                <tr>
                                    <td><?= ++$key; ?></td>
                                    <td><?= $value->transaction_date; ?></td>
                                    <td>
                                        <?php foreach ($value->transaction_details as $key => $detail) { ?>
                                            <div style="padding-bottom:0px;">
                                                <table class="table w-100" style="font-size:12px;pointer-events:none; margin-bottom: 3px;">
                                                    <tbody>
                                                        <tr>
                                                            <td width="75%" style="padding: 5px 3px 5px 3px;border-bottom:1px solid #ccc;">- <?= strtoupper($detail->name) ?> <span style="width:0px; border-bottom:1px solid #ccc; padding: 3px 7px;" class="label bg-maroon">5</span></td>
                                                            <td style="padding: 5px 3px 5px 3px;text-align:right;border-bottom:1px solid #ccc;">
                                                                <?= !empty($detail->discount) ? 'Rp. ' . number_format(floatval($detail->price * $detail->quantity), 0,  '.', '.') . ' - ' . 'Rp. ' . number_format(floatval($detail->discount), 0, '.', '.') . ' = ' . 'Rp. ' . number_format(floatval(($detail->price * $detail->quantity) - $detail->discount), 0, '.', '.') : 'Rp. ' . number_format(floatval($detail->price * $detail->quantity), 0,  '.', '.') ?>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php } ?>
                                    </td>
                                    <td><?= $value->status; ?></td>
                                    <td><?= 'Rp. '.number_format($value->total, 0, '.', ',').',-'; ?></td>
                                </tr>
                            <?php } ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-5 col-12">
            <div class="box">
                <div class="box-header">
                    <h5 class="box-title">Stok Hampir Habis</h5>
                </div>
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table table table-bordered table-hovered table-striped">
                            <tr>
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Jumlah Produk</th>
                                <th>Total</th>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $this->load->view('layouts/v_footer') ?>
<script>
    
    $(function() {
        let labelIncomePerMonth = []
        let dataIncomePerMonth = []
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Total Penjualan',
                    data: [],
                    backgroundColor: '#2C7CAB',
                    borderColor: '#2C7CAB',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    },
                },
                // set property untuk realtime
                animation: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            title: function(context) {
                                let labelTitle = context[0].label
                                return 'Tanggal : ' + labelTitle + ' ' + '<?= bulanIndo(date('m')).' '.date('Y') ?>';
                            },
                            label: function(context) {
                                var label = context.dataset.label || '';

                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed.y !== null) {
                                    label += new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(context.parsed.y);
                                }
                                return label;
                            }
                        }
                    }
                }
            }
        });
        let updateIncomePerMonth = function () {
            $.ajax({
                url: "<?= base_url() ?>dashboard/getGraphPerMonth",
                type: "GET",
                dataType: "json",
                success:function($res) {
                    let labelIncomePerMonth = $res.line_graph_per_month.map(e => e.day)
                    let dataIncomePerMonth = $res.line_graph_per_month.map(e => e.total)

                    // masukkan ke label dan dataset chart
                    myChart.data.labels = labelIncomePerMonth
                    myChart.data.datasets[0].data = dataIncomePerMonth
                    myChart.update()
                }
            })
        }
        updateIncomePerMonth()
        // update realtime tiap 2 detik, transaksi terbaru
        setInterval(function () {
            updateIncomePerMonth()
        }, 2000);

        var ctxPie = document.getElementById('myChartPie').getContext('2d');
        var myChartPie = new Chart(ctxPie, {
            type: 'doughnut',
            data: {
                labels: [],
                datasets: [{
                    label: '# of Votes',
                    data: [],
                    backgroundColor: [
                        'rgb(255, 99, 132)',
                        'rgb(54, 162, 235)',
                        'rgb(255, 205, 86)'
                    ],
                    hoverOffset: 4
                }]
            },
            options: {
                scales: {
                    yAxis: {
                        grid: {
                            display: true,
                        },
                        ticks: {
                            // Include a dollar sign in the ticks
                            callback: function(value, index, values) {
                                return '';
                            }
                        },
                    },
                },
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.label ?? ''
                                let value = context.parsed
                                return label + ' : ' + value + ' item (quantity)'
                            }
                        }
                    }
                }
            }
        });
        
        let updateBestSellerProducts = function () {
            $.ajax({
                url: "<?= base_url() ?>dashboard/bestSellerProduct",
                type: "GET",
                dataType: "json",
                success:function($res) {
                    let labelBestSellerProducts = $res.pie_graph_products.map(e => e.name)
                    let dataBestSellerProducts = $res.pie_graph_products.map(e => e.total)

                    // masukkan ke label dan dataset chart
                    myChartPie.data.labels = labelBestSellerProducts
                    myChartPie.data.datasets[0].data = dataBestSellerProducts
                    myChartPie.update()
                }
            })
        }
        updateBestSellerProducts()
        // update realtime tiap 2 detik, transaksi terbaru
        setInterval(function () {
            updateBestSellerProducts()
        }, 2000);
    })

</script>
