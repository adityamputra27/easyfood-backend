<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->loginCheck();
		$this->load->model('sistem_model');
	}
	public function index()
	{
		$this->db->select('sti.*, p.name');
		$this->db->from('stock_ins as sti');
		$this->db->join('products as p', 'sti.products_id = p.id');
		$stockIns = $this->db->get()->result();

		$expiredProducts = [];
		foreach ($stockIns as $key => $value) {
			$expiredDate = new DateTime($value->expired_date);
			$dateNow = new DateTime(date('Y-m-d'));

			if ($value->expired_date != '0000-00-00' 
				&& $value->expired_date != '' 
				&& $value->expired_date != null
				&& $dateNow < $expiredDate 
				&& date('Y') == date('Y', strtotime($value->expired_date))
				&& $dateNow->diff($expiredDate)->m <= 2
			) {
				$value->expired_year = $dateNow->diff($expiredDate)->y;
				$value->expired_month = $dateNow->diff($expiredDate)->m;
				$value->expired_day = $dateNow->diff($expiredDate)->d;
				$value->expired_status = 'ACTIVE';
			} else if(strtotime(date('Y-m-d')) >= strtotime($value->expired_date)
				&& $value->expired_date != '' 
				&& $value->expired_date != null
			) {
				$value->expired_status = 'INACTIVE';
			} else {
				$value->expired_status = '-';
			}
			$expiredProducts[] = $value;
		}
		$data['expiredProducts'] = $expiredProducts;

		$this->db->select('count(name) as total_product');
		$totalProducts = $this->db->get('products');
		$data['totalProduct'] = $totalProducts->row_array()['total_product'];

		$this->db->select('count(total) as total_transaction');
		$totalTransaction = $this->db->get('transactions');
		$data['totalTransaction'] = $totalTransaction->row_array()['total_transaction'];

		$today = date('Y-m-d');
		$this->db->select('sum(total) as total_today, count(total) as total_transaction_today');
		$this->db->where("created_at BETWEEN '".$today." 00:00:00 ' AND '".$today." 23:59:59'");
		$transactionToday = $this->db->get('transactions');

		$data['incomeTransactionToday'] = 'Rp. '.number_format($transactionToday->row()->total_today).',-';
		$data['totalTransactionToday'] = $transactionToday->row_array()['total_transaction_today'];

		$this->db->select('transactions.*');
        $this->db->join('users', 'transactions.users_id = users.id');
        $this->db->order_by('transactions.transaction_date', 'DESC');
		$this->db->limit(3);
        $transactions = $this->db->get('transactions')->result();
        foreach ($transactions as $key => &$value) {
            $this->db->select('transaction_details.*, products.name');
            $this->db->from('transaction_details');
            $this->db->join('transactions', 'transactions.id = transaction_details.transactions_id');
			$this->db->join('products', 'transaction_details.products_id = products.id');
            $this->db->where('transaction_details.transactions_id', $value->id);
            $value->transaction_details = $this->db->get()->result();
        }

        $data['lastTransctions'] = $transactions;

		$this->load->view('v_dashboard', $data);
	}
	public function getGraphPerMonth()
	{
		$arrayDay = [];
		$arrayTotal = [];
		$monthYear = date('Y-m');
		// buat 31 hari
		for ($i = 1; $i <= 31; $i++) { 
			$arrayDay[]['day'] = $i;
			$this->db->select("sum(total) as total");
			$this->db->where("transaction_date BETWEEN '".$monthYear."-".$i." 00:00:00' AND '".$monthYear."-".$i." 23:59:59'");
			$total = $this->db->get('transactions')->row_array()['total'];
			if (empty($total)) {
				$total = floatval(0);
			}
			$arrayTotal[]['total'] = floatval($total);
		}
		// tampung kembali
		$graph = [];
		foreach ($arrayDay as $dayKey => $day) {
			$graph[$dayKey]['day'] = $day['day'];
		}
		foreach ($arrayTotal as $totalKey => $total) {
			$graph[$totalKey]['total'] = $total['total'];
		}
		$data['line_graph_per_month'] = $graph;

		$data['session'] = $this->session->userdata();

		echo json_encode($data);
	}
	public function bestSellerProduct()
	{
		// jumlah quantity di trans details berdasarkan products_id
		$this->db->select('transaction_details.products_id as group_id, products.name, sum(transaction_details.quantity) as total');
		$this->db->group_by('transaction_details.products_id');
		$this->db->order_by('total', 'DESC');
		$this->db->join('products', 'products.id = transaction_details.products_id');

		$products = $this->db->get('transaction_details', 5);
		$data['pie_graph_products'] = $products->result();

		echo json_encode($data);
	}
}
