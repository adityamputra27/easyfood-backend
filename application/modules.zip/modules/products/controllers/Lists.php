<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Lists extends CI_Controller
{
	public $settings;
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->model('sistem_model');
		$this->load->model('lists_model');
        $this->load->model("stocks_model");
		$this->load->library(['encryption', 'upload']);
		$this->load->helper(["url", "html", "form"]);
		$this->load->helper('url');
		$this->load->helper('string');
		$this->load->helper("file");
		$this->loginCheck();

		$this->settings = $this->sistem_model->_get_only_limit('settings', 'shop_name-ASC', '1');

        include APPPATH.'third_party/PHPExcel/Classes/PHPExcel.php';
	}
	public function index()
	{
		$this->load->view('v_lists');
	}
	public function store()
	{
		$data = [
			'barcode' => $this->input->post('barcodeInput'),
			'name' => $this->input->post('productNameInput'),
			'capital_price' => parent::checkPrice($this->input->post('capitalPriceInput')),
			'selling_price' => parent::checkPrice($this->input->post('sellingPriceInput')),
			'sub_total' => floatval(parent::checkPrice($this->input->post('capitalPriceInput')) * $this->input->post('stockInput')),
			'product_categories_id' => $this->input->post('categoryIdInput'),
			'product_units_id' => $this->input->post('unitProductInput'),
			'stock' => 0,
			'information' => $this->input->post('informationInput'),
			'updated_at' => date('Y-m-d H:i:s'),
			'created_at' => date('Y-m-d H:i:s')
		];
		$this->sistem_model->_input('products', $data);

		$response['status'] = true;
		$response['message'] = 'Data Produk Berhasil Di Tambahkan!';
		$response['data'] = $data;

		echo json_encode($response);
	}
	public function edit($id)
	{
		$check = $this->sistem_model->_get_where_id('products', array('MD5(id)' => $id));

		if (count($check) > 0) {
			$data = [
				'barcode' => $this->input->post('barcodeInput'),
				'name' => $this->input->post('productNameInput'),
				'capital_price' => parent::checkPrice($this->input->post('capitalPriceInput')),
				'selling_price' => parent::checkPrice($this->input->post('sellingPriceInput')),
				'sub_total' => floatval(parent::checkPrice($this->input->post('capitalPriceInput')) * $this->input->post('stockInput')),
				'product_categories_id' => $this->input->post('categoryIdInput'),
				'product_units_id' => $this->input->post('unitProductInput'),
				'stock' => 0,
				'information' => $this->input->post('informationInput'),
				'updated_at' => date('Y-m-d H:i:s')
			];
			$this->sistem_model->_update('products', $data, array('MD5(id)' => $id));
			$response['status'] = true;
			$response['message'] = 'Data Produk Berhasil Di Update!';
			$response['data'] = null;
		} else {
			$response['status'] = false;
			$response['message'] = 'ID Produk Tidak Ditemukan!';
			$response['data'] = null;
		}

		echo json_encode($response);
	}
	public function delete($id)
	{
		$check = $this->sistem_model->_get_where_id('products', array('MD5(id)' => $id));

		if (count($check) > 0) {
			$this->sistem_model->_delete('products', array('MD5(id)' => $id));
			$response['status'] = true;
			$response['message'] = 'Data Produk Berhasil Di Hapus!';
			$response['data'] = null;
		} else {
			$response['status'] = false;
			$response['message'] = 'ID Produk Tidak Ditemukan!';
			$response['data'] = null;
		}

		echo json_encode($response);
	}
	public function getProduct()
	{
		$list = $this->lists_model->_getDatatables();
		$data = array();
		$no = $_POST['start'];
		$draw = $_POST['draw'];

		foreach ($list as $key => $value) {
			$id = MD5($value->id);
			$link = '<div class="btn-group">';
			$link .= '<button class="btn btn-primary btn-sm product_stocks" data-id="'.$id.'"><i class="fa fa-bars"></i> Stok</button>';
			$link .= '<button type="button" class="btn btn-warning btn-sm" data-mode="edit" data-toggle="modal" data-target="#productModal" data-id="' . $id . '" 
						data-product_categories_id="' . $value->product_categories_id . '" 
						data-product_units_id="' . $value->product_units_id . '"
						data-information="'. $value->information .'"><i class="fa fa-edit"></i> Edit</button>';
			$link .= '<button type="button" class="btn btn-danger btn-sm delete-product" data-id="' . $id . '"><i class="fa fa-trash"></i> Hapus</a>';
			$link .= '</div>';

			$no++;
			$row = array();
			$row[] = $no;
			$row[] = '<span class="label bg-maroon">'.$value->barcode.'</span>';
			$row[] = $value->name;
			$row[] = $value->category_name;
			$row[] = $value->unit_name;
			$row[] = 'Rp. ' . number_format($value->capital_price, 0, '.', '.');
			$row[] = 'Rp. ' . number_format($value->selling_price, 0, '.', '.');
			$row[] = $value->information;
			$row[] = $link;
			$data[] = $row;
		}

		$output = [
			'draw' => $draw,
			'recordsTotal' => $this->lists_model->_countAll(),
			'recordsFiltered' => $this->lists_model->_countFiltered(),
			'data' => $data
		];

		echo json_encode($output);
	}
	public function updateSingleProduct()
	{
		$post = $this->input->post();
		$data['barcode'] = $this->input->post('barcode');
		$this->sistem_model->_update('products', $data, array('id' => $post['products_id']));
		$response['message'] = 'Berhasil Update Barcode!';
		$response['data'] = $this->sistem_model->_get('products');

		echo json_encode($response);
	}
	public function updateProductName()
	{
		$post = $this->input->post();
		$data['name'] = $this->input->post('name');
		$this->sistem_model->_update('products', $data, array('id' => $post['products_id']));
		$response['message'] = 'Berhasil Update Nama Produk!';
		$response['data'] = $this->sistem_model->_get('products');

		echo json_encode($response);
	}
	public function updateCapitalPrice()
	{
		$post = $this->input->post();
		$data['capital_price'] = parent::checkPrice($this->input->post('capital_price'));
		$this->sistem_model->_update('products', $data, array('id' => $post['products_id']));
		$response['message'] = 'Berhasil Update Harga Modal!';
		$response['data'] = $this->sistem_model->_get('products');

		echo json_encode($response);
	}
	public function updateSellingPrice()
	{
		$post = $this->input->post();
		$data['selling_price'] = parent::checkPrice(($this->input->post('selling_price')));
		$this->sistem_model->_update('products', $data, array('id' => $post['products_id']));
		$response['message'] = 'Berhasil Update Harga Jual!';
		$response['data'] = $this->sistem_model->_get('products');

		echo json_encode($response);
	}
	public function getSearchProduct()
	{
		$lists = $this->lists_model->_getDatatables();
		$no = $this->input->post('no');
		$draw = $this->input->post('draw');
		$data = [];

		foreach ($lists as $key => $value) {
			$link = '<button type="button" class="btn btn-info btn-sm selectProduct" id="selectProduct" data-idproduct="' . $value->id . '" data-name="' . $value->name . '"><i class="glyphicon glyphicon-arrow-down"></i> Pilih</button>';
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = '<span class="label bg-maroon">'.$value->barcode.'</span>';
			$row[] = $value->name;
			$row[] = $value->unit_name;
			$row[] = 'Rp. ' . number_format($value->selling_price) . ',-';
			$row[] = $link;
			$data[] = $row;
		}

		$output = [
			'draw' => $draw,
			'recordsTotal' => $this->lists_model->_countAll(),
			'recordsFiltered' => $this->lists_model->_countFiltered(),
			'data' => $data
		];

		echo json_encode($output);
	}

	public function getStockProduct()
	{
		$list = $this->stocks_model->_getDatatables();
        $data = [];
        $no = $_POST["start"];
        $draw = $_POST["draw"];

        foreach ($list as $key => $value) {
            $no++;
			$link = '<button type="button" class="btn btn-info btn-sm selectStockProduct" id="selectStockProduct" data-idproduct="' . $value->products_id . '" data-name="' . $value->name . '" data-selling="' . $value->selling_price . '" data-capital="' . $value->capital_price . '" data-barcode="' . $value->barcode . '" data-total="' . $value->total . '" data-id="' . $value->id . '" data-unit="'.$value->unit_name.'"><i class="glyphicon glyphicon-arrow-down"></i> Pilih</button>';
            $row = [];
            $row[] = $no;
            $row[] = date('d-m-Y H:i:s', strtotime($value->date));
            $row[] = $value->total." "."(".$value->unit_name.")";
            $row[] = isset($value->expired_date) && $value->expired_date != '0000-00-00' ? date('d-m-Y', strtotime($value->expired_date)) : '-';
            $row[] = $value->status;
            $row[] = $value->description;
			$row[] = $link;
            $data[] = $row;
        }

        $output = [
            "draw" => $draw,
            "recordsTotal" => $this->stocks_model->_countAll(),
            "recordsFiltered" => $this->stocks_model->_countFiltered(),
            "data" => $data,
        ];

        echo json_encode($output);
	}

	public function loadCategory()
	{
		$category = $this->sistem_model->_get('product_categories', 'category_name-ASC');
		if (!empty($category)) {
			$response['status'] = false;
			$response['message'] = 'Data Kategori Produk Kosong!';
			$response['data'] = null;
		}
		$response['status'] = true;
		$response['message'] = 'Success Get Data Category!';
		$response['data'] = $category;

		echo json_encode($response);
	}
	public function loadUnit()
	{
		$unit = $this->sistem_model->_get('product_units', 'unit_name-ASC');
		if (!empty($unit)) {
			$response['status'] = false;
			$response['message'] = 'Data Satuan Produk Kosong!';
			$response['data'] = null;
		}
		$response['status'] = true;
		$response['message'] = 'Success Get Data Product Unit!';
		$response['data'] = $unit;

		echo json_encode($response);
	}
	public function generateBarcode()
	{
		$prefixBarcode = !empty($this->settings[0]['prefix_barcode']) ? $this->settings[0]['prefix_barcode'] . random_string('numeric', 6) : random_string('numeric', 9);

		$response['status'] = true;
		$response['message'] = 'Success Get Barcode';
		$response['barcode'] = $prefixBarcode;

		echo json_encode($response);
	}

	public function loadProduct()
	{
		$list = $this->lists_model->_getDatatables();
		$data = array();
		$no = $_POST['start'];
		$draw = $_POST['draw'];

		foreach ($list as $key => $value) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = '<span class="label bg-maroon">'.$value->barcode.'</span>';
			$row[] = $value->name;
			$row[] = $value->unit_name;
			$row[] = $value->selling_price;
			$row[] = $value->stock;
			$data[] = $row;
		}

		$output = [
			'draw' => $draw,
			'recordsTotal' => $this->lists_model->_countAll(),
			'recordsFiltered' => $this->lists_model->_countFiltered(),
			'data' => $data
		];

		echo json_encode($output);
	}

	public function export()
	{
		$this->db->select('p.*, pc.category_name, pu.unit_name');
		$this->db->from('products as p');
		$this->db->join('product_categories as pc', 'p.product_categories_id = pc.id', 'left');
		$this->db->join('product_units as pu', 'p.product_units_id = pu.id', 'left');
		$this->db->order_by('p.name', 'ASC');
		$products = $this->db->get()->result();

		foreach ($products as $key => $value) {
			$this->db->select('SUM(sti.total) as total');
			$this->db->from('stock_ins as sti');
			$this->db->where('sti.products_id', $value->id);
			
			$value->stock_in = $this->db->get()->row();
		}

		foreach ($products as $key => $value) {
			$this->db->select('SUM(sto.total) as total');
			$this->db->from('stock_outs as sto');
			$this->db->where('sto.products_id', $value->id);
			
			$value->stock_out = $this->db->get()->row();
		}

		$this->db->select('*');
		$this->db->from('settings');
		$settings = $this->db->get()->row();

        $excel = new PHPExcel();
        $columnStyle = [
            'font' => ['bold' => TRUE],
            'alignment' => [
                'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
            ],
            'borders' => [
                'top' => ['style' => PHPExcel_Style_Border::BORDER_THIN],
                'right' => ['style' => PHPExcel_Style_Border::BORDER_THIN],
                'bottom' => ['style' => PHPExcel_Style_Border::BORDER_THIN],
                'left' => ['style' => PHPExcel_Style_Border::BORDER_THIN],
            ]
        ];

        $rowStyle = [
            'font' => ['bold' => FALSE],
            'alignment' => [
                'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT,
                'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER 
            ],
            'borders' => [
                'top' => ['style' => PHPExcel_Style_Border::BORDER_THIN],
                'right' => ['style' => PHPExcel_Style_Border::BORDER_THIN],
                'bottom' => ['style' => PHPExcel_Style_Border::BORDER_THIN],
                'left' => ['style' => PHPExcel_Style_Border::BORDER_THIN]
            ]
        ];

        $excel->setActiveSheetIndex(0)->setCellValue('A1', 'Data Produk - '.$settings->shop_name);
        $excel->getActiveSheet()->mergeCells('A1:J1');
        $excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE);
        $excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(15);
        $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $excel->setActiveSheetIndex(0)->setCellValue('A3', 'No');
        $excel->setActiveSheetIndex(0)->setCellValue('B3', 'Barcode');
        $excel->setActiveSheetIndex(0)->setCellValue('C3', 'Nama');
        $excel->setActiveSheetIndex(0)->setCellValue('D3', 'Kategori');
        $excel->setActiveSheetIndex(0)->setCellValue('E3', 'Satuan');
        $excel->setActiveSheetIndex(0)->setCellValue('F3', 'Harga Modal');
        $excel->setActiveSheetIndex(0)->setCellValue('G3', 'Harga Jual');
        $excel->setActiveSheetIndex(0)->setCellValue('H3', 'Stok Masuk');
        $excel->setActiveSheetIndex(0)->setCellValue('I3', 'Stok Keluar');
        $excel->setActiveSheetIndex(0)->setCellValue('J3', 'Sisa Stok');

        $excel->getActiveSheet()->getStyle('A3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('B3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('C3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('D3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('E3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('F3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('G3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('H3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('I3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('J3')->applyFromArray($columnStyle);

        $no = 1;
        $numRow = 4;

		foreach ($products as $key => $value) {

			$stockInTotal = isset($value->stock_in->total) ? $value->stock_in->total : 0;
			$stockOutTotal = isset($value->stock_out->total) ? $value->stock_out->total : 0;

			$excel->setActiveSheetIndex(0)->setCellValue('A'.$numRow, $no++);
			$excel->setActiveSheetIndex(0)->setCellValue('B'.$numRow, $value->barcode);
			$excel->setActiveSheetIndex(0)->setCellValue('C'.$numRow, $value->name);
			$excel->setActiveSheetIndex(0)->setCellValue('D'.$numRow, $value->category_name);
			$excel->setActiveSheetIndex(0)->setCellValue('E'.$numRow, $value->unit_name);
			$excel->setActiveSheetIndex(0)->setCellValue('F'.$numRow, $value->capital_price);
			$excel->setActiveSheetIndex(0)->setCellValue('G'.$numRow, $value->selling_price);
			$excel->setActiveSheetIndex(0)->setCellValue('H'.$numRow, $stockInTotal);
			$excel->setActiveSheetIndex(0)->setCellValue('I'.$numRow, $stockOutTotal);
			$excel->setActiveSheetIndex(0)->setCellValue('J'.$numRow, $stockInTotal - $stockOutTotal);

			$excel->getActiveSheet()->getStyle('A'.$numRow)->applyFromArray($rowStyle);
			$excel->getActiveSheet()->getStyle('B'.$numRow)->applyFromArray($rowStyle);
			$excel->getActiveSheet()->getStyle('C'.$numRow)->applyFromArray($rowStyle);
			$excel->getActiveSheet()->getStyle('D'.$numRow)->applyFromArray($rowStyle);
			$excel->getActiveSheet()->getStyle('E'.$numRow)->applyFromArray($rowStyle);
			$excel->getActiveSheet()->getStyle('F'.$numRow)->applyFromArray($rowStyle);
			$excel->getActiveSheet()->getStyle('G'.$numRow)->applyFromArray($rowStyle);
			$excel->getActiveSheet()->getStyle('H'.$numRow)->applyFromArray($rowStyle);
			$excel->getActiveSheet()->getStyle('I'.$numRow)->applyFromArray($rowStyle);
			$excel->getActiveSheet()->getStyle('J'.$numRow)->applyFromArray($rowStyle);
			$numRow++;
		}

		$excel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
        $excel->getActiveSheet()->getColumnDimension('B')->setWidth(11);
        $excel->getActiveSheet()->getColumnDimension('C')->setWidth(65);
        $excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
        $excel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
        $excel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
        $excel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
        $excel->getActiveSheet()->getColumnDimension('I')->setWidth(15);
        $excel->getActiveSheet()->getColumnDimension('J')->setWidth(15);

		$fileName = 'Export_Produk_'.date('d-m-Y').'.xls';
        $objectWriter = PHPExcel_IOFactory::createWriter($excel, 'Excel5');
        ob_end_clean();

        header('Content-type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename='.$fileName);
        $objectWriter->save('php://output');
	}

	public function template()
	{
		$this->db->select('*');
		$this->db->from('settings');
		$settings = $this->db->get()->row();

        $excel = new PHPExcel();
        $columnStyle = [
            'font' => ['bold' => TRUE],
            'alignment' => [
                'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
            ],
            'borders' => [
                'top' => ['style' => PHPExcel_Style_Border::BORDER_THIN],
                'right' => ['style' => PHPExcel_Style_Border::BORDER_THIN],
                'bottom' => ['style' => PHPExcel_Style_Border::BORDER_THIN],
                'left' => ['style' => PHPExcel_Style_Border::BORDER_THIN],
            ]
        ];

        $rowStyle = [
            'font' => ['bold' => FALSE],
            'alignment' => [
                'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT,
                'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER 
            ],
            'borders' => [
                'top' => ['style' => PHPExcel_Style_Border::BORDER_THIN],
                'right' => ['style' => PHPExcel_Style_Border::BORDER_THIN],
                'bottom' => ['style' => PHPExcel_Style_Border::BORDER_THIN],
                'left' => ['style' => PHPExcel_Style_Border::BORDER_THIN]
            ]
        ];

		$excel->setActiveSheetIndex(0)->setCellValue('A1', 'Data Produk - '.$settings->shop_name);
        $excel->getActiveSheet()->mergeCells('A1:G1');
        $excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE);
        $excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(15);
        $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $excel->setActiveSheetIndex(0)->setCellValue('A3', 'No');
        $excel->setActiveSheetIndex(0)->setCellValue('B3', 'Nama');
        $excel->setActiveSheetIndex(0)->setCellValue('C3', 'Kategori');
        $excel->setActiveSheetIndex(0)->setCellValue('D3', 'Satuan');
        $excel->setActiveSheetIndex(0)->setCellValue('E3', 'Harga Modal');
        $excel->setActiveSheetIndex(0)->setCellValue('F3', 'Harga Jual');
        $excel->setActiveSheetIndex(0)->setCellValue('G3', 'Keterangan');

        $excel->getActiveSheet()->getStyle('A3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('B3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('C3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('D3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('E3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('F3')->applyFromArray($columnStyle);
        $excel->getActiveSheet()->getStyle('G3')->applyFromArray($columnStyle);

		$fileName = 'Template_Import_Produk_'.date('d-m-Y').'.xlsx';
        $objectWriter = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        ob_end_clean();

        header('Content-type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename='.$fileName);
        $objectWriter->save('php://output');
	}

	public function import()
	{
		$path = "imports/";
		$config['upload_path'] = $path;
		$config['allowed_types'] = 'xlsx|xls|csv';
		$config['remove_spaces'] = true;

		$this->load->library('upload', $config);
		$this->upload->initialize($config);

		if (!$this->upload->do_upload("import")) {
			$error = ["error" => $this->upload->display_errors()];
		} else {
			$data = ["upload_data" => $this->upload->data()];
		}

		if (empty($error)) {
			if (!empty($data['upload_data']['file_name'])) {
				$import = $data['upload_data']['file_name'];
			} else {
				$import = 0;
			}
			$fileName = $path . $import;
			try {
				if (PHPExcel_IOFactory::identify($fileName)) {
					$fileType = PHPExcel_IOFactory::identify($fileName);
					$objReader = PHPExcel_IOFactory::createReader($fileType);
					$objPHPExcel = $objReader->load($fileName);

					foreach ($objPHPExcel->getWorksheetIterator() as $key => $worksheet) {
						$highestRow = $worksheet->getHighestRow();
						for ($row = 4; $row <= $highestRow; $row++) { 
							$insertData[] = [
								'barcode' => !empty($this->settings[0]['prefix_barcode']) 
											? $this->settings[0]['prefix_barcode'] . random_string('numeric', 6) 
											: random_string('numeric', 9),
								'name' => $worksheet->getCellByColumnAndRow(1, $row)->getValue(),
								'product_categories_id' => $this->lists_model->getProductCategoryByName($worksheet->getCellByColumnAndRow(2, $row)->getValue()),
								'product_units_id' => $this->lists_model->getProductUnitByName($worksheet->getCellByColumnAndRow(3, $row)->getValue()),
								'capital_price' => $worksheet->getCellByColumnAndRow(4, $row)->getValue(),
								'selling_price' => $worksheet->getCellByColumnAndRow(5, $row)->getValue(),
								'information' => $worksheet->getCellByColumnAndRow(6, $row)->getValue(),
							];
						}
					}
					$this->lists_model->insertBatch($insertData);
					$response['status'] = true;
					$response['message'] = 'Import data produk berhasil!';
					delete_files($path);
				} else {
					$response['status'] = false;
					$response['message'] = 'File excel tidak valid!';
				}
			} catch (Exception $e) {
				$response['status'] = false;
				$response['message'] = $e->getMessage();
			}
		} else {
			$response['status'] = false;
			$response['message'] = $error['error'];
		}
		echo json_encode($response);
	}

	public function importSecc()
	{
		$config['allowed_types'] = 'xlsx|xls|csv';
		$config['remove_spaces'] = true;
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		if (!$this->upload->do_upload("import")) {
			$error = ["error" => $this->upload->display_errors()];
		} else {
			$data = ["upload_data" => $this->upload->data()];
		}
		if (empty($error)) {
			if (!empty($data['upload_data']['file_name'])) {
				$importFileName = $data['upload_data']['file_name'];
			} else {
				$importFileName = 0;
			}
			try {
				$importFileType = PHPExcel_IOFactory::identify($importFileName);
				$objReader = PHPExcel_IOFactory::createReader($importFileType);
				$objPHPExcel = $objReader->load($importFileName);
				$allDataInSheet = $objPHPExcel->getActiveSheet()
												->toArray(null, true, true, true);
				$flag = true;
				$inc = 0;
				foreach ($allDataInSheet as $key => $value) {
					if ($flag) {
						$flag = false;
						continue;
					}
					$insertData[$inc]["barcode"] = !empty($this->settings[0]['prefix_barcode']) 
													? $this->settings[0]['prefix_barcode'] . random_string('numeric', 6) 
													: random_string('numeric', 9);
					$insertData[$inc]["name"] = $value["B"];
					$insertData[$inc]["capital_price"] = $value["E"];
					$insertData[$inc]["selling_price"] = $value["F"];
					$inc++;
				}
				$result = $this->lists_model->insertBatch($insertData);
				if ($result) {
					echo 'Imported successfully';
				} else {
					echo "ERROR!";
				}
			} catch (Exception $e) {
				die(
					'Error loading file! "' .pathinfo($importFileName, PATHINFO_BASENAME). '" ' . $e->getMessage()
				);
			}
		}
	}
}
