<?php $this->load->view('layouts/v_header') ?>
<section class="content-header">
    <h1>
        Data Produk
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-shopping-bag"></i> Produk</a></li>
        <li class="active">Data Produk</li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header">
                    <div class="btn-group">
                        <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#productModal"><i class="fa fa-plus-circle"></i> Tambah</a>
                        <div class="input-group-btn">
                            <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Lainnya
                                <span class="fa fa-caret-down"></span>
                            </button>
                            <ul class="dropdown-menu">
                                <li><a href="<?= base_url() ?>products/lists/export">Export</a></li>
                                <li><a href="#" data-toggle="modal" data-target="#importModal">Import</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="box-body">
                    <table id="product" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th width="10px" class="text-center">No</th>
                                <th width='10px'>Barcode</th>
                                <th>Nama</th>
                                <th>Kategori</th>
                                <th>Satuan</th>
                                <th>Harga Modal</th>
                                <th>Harga Jual</th>
                                <th>Keterangan</th>
                                <th width='180px' class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="modal fade" id="productModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form action="<?= base_url() ?>products/lists/store" id="productForm" method="POST">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Tambah Produk</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group row">
                                <label for="" class="col-sm-3 col-form-label">Barcode</label>
                                <div class="col-sm-9">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="barcodeInput" name="barcodeInput">
                                        <span class="input-group-btn">
                                            <button type="button" id="generateBarcode" class="btn btn-info btn-flat"><i class="fa fa-refresh"></i></button>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="" class="col-sm-3 col-form-label">Nama</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="productNameInput" name="productNameInput">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="" class="col-sm-3 col-form-label">Harga Modal</label>
                                <div class="col-sm-9">
                                    <div class="input-group">
                                        <div class="input-group-addon">Rp.</div>
                                        <input type="text" class="form-control" name="capitalPriceInput" id="capitalPriceInput" placeholder="0" autocomplete="off">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="" class="col-sm-3 col-form-label">Harga Jual</label>
                                <div class="col-sm-9">
                                    <div class="input-group">
                                        <div class="input-group-addon">Rp.</div>
                                        <input type="text" class="form-control" name="sellingPriceInput" id="sellingPriceInput" placeholder="0" autocomplete="off">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group row">
                                <label for="" class="col-sm-3 col-form-label">Kategori</label>
                                <div class="col-sm-9">
                                    <select name="categoryIdInput" id="categoryIdInput" class="form-control" style="width: 100%;">
                                        <option value=""></option>

                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="" class="col-sm-3 col-form-label">Satuan</label>
                                <div class="col-sm-9">
                                    <select name="unitProductInput" id="unitProductInput" class="form-control" style="width: 100%;">
                                        <option value=""></option>

                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="" class="col-sm-3 col-form-label">Keterangan</label>
                                <div class="col-sm-9">
                                    <input class="form-control" name="informationInput" id="informationInput">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal"><i class="fa fa-times-circle"></i> Tutup</button>
                    <button type="submit" class="btn btn-primary" id="submitProduct"><i class="fa fa-check-circle"></i> Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="importModal" tabindex="-1" role="dialog" aria-labelledby="importModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
        <div class="modal-content">
            <form action="<?= base_url() ?>products/lists/import" method="POST" id="importForm" enctype="multipart/form-data">
                <div class="modal-header">
                    <h4 class="modal-title">Import Produk</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <a href="<?= base_url() ?>products/lists/template" class="btn btn-default btn-block"><i class="fa fa-download"></i> Download Template (.xslx)</a>
                    </div>
                    <div class="form-group">
                        <input type="file" name="import" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary btn-block"><i class="fa fa-check-circle"></i> Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $this->load->view('layouts/v_footer') ?>
<script>
    $(function() {
        function generateCurrency(angka, prefix) {
            var number_string = angka.replace(/[^,\d]/g, '').toString(),
                split = number_string.split(','),
                sisa = split[0].length % 3,
                rupiah = split[0].substr(0, sisa),
                ribuan = split[0].substr(sisa).match(/\d{3}/gi);

            if (ribuan) {
                separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
            }

            rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
            return prefix == undefined ? rupiah : (rupiah ? '' + rupiah : '');
        }

        function currencyFormatRupiah(elemValue) {
            return $(elemValue).val(generateCurrency($(elemValue).val(), 'Rp. '))
        }

        $(document).on('keyup', '#capitalPriceInput', function(e) {
            currencyFormatRupiah(this)
        })
        $(document).on('keyup', '#sellingPriceInput', function(e) {
            currencyFormatRupiah(this)
        })
        $('body').on('click', '.delete-product', function() {
            let trParents = $(this).parents().parents().closest('tr')
            let dataName = trParents.find('td:eq(2)').text()
            swal({
                title: "Apakah kamu yakin?",
                text: `Data ${dataName} akan dihapus?`,
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((confirmDelete) => {
                if (confirmDelete) {
                    let id = $(this).attr('data-id')
                    $.ajax({
                        url: `<?= base_url() ?>products/lists/delete/${id}`,
                        type: 'DELETE',
                        dataType: 'json',
                        success: function(response) {
                            if (response.status == true) {
                                swal({
                                    title: "Berhasil!",
                                    text: response.message,
                                    icon: "success",
                                }).then(function() {
                                    tableProduct.ajax.reload();
                                });
                            } else {
                                swal({
                                    title: "Gagal!",
                                    text: response.message,
                                    icon: "error",
                                })
                            }
                        }
                    })
                }
            });
        })

        function loadCategory() {
            $('#categoryIdInput').select2({
                placeholder: "PILIH KATEGORI PRODUK",
                allowClear: true
            })
            $.ajax({
                url: '<?= base_url() ?>products/lists/loadCategory',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status == true) {
                        $('#categoryIdInput').prop('disabled', false)
                        // $('#categoryIdInput').append(`<option>${response.data[0].category_name}</option>`)
                        response.data.forEach((e, i) => {
                            $('#categoryIdInput').append(`<option value="${e.id}">${e.category_name}</option>`)
                            // console.log(e, i)
                        })
                    } else {
                        $('#categoryIdInput').prop('disabled', true)
                    }
                }
            })
        }

        function loadUnit() {
            $('#unitProductInput').select2({
                placeholder: "PILIH UNIT PRODUK",
                allowClear: true
            })
            $.ajax({
                url: '<?= base_url() ?>products/lists/loadUnit',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status == true) {
                        response.data.forEach((e, i) => {
                            $('#unitProductInput').append(`<option value="${e.id}">${e.unit_name}</option>`)
                        })
                    } else {
                        $('#unitProductInput').prop('disabled', true)
                    }
                }
            })
        }

        function generateProductBarcode() {
            $.ajax({
                url: '<?= base_url() ?>products/lists/generateBarcode',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status == true) {
                        $('#barcodeInput').val(response.barcode)
                    }
                }
            })
        }

        let tableProduct = $('#product').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Indonesian.json"
            },
            "processing": true,
            "serverSide": true,
            "order": [],
            "ajax": {
                "url": "<?= base_url() ?>products/lists/getProduct",
                "type": "POST"
            },
            "columnDefs": [{
                    "targets": [0],
                    "orderable": false,
                },
                {
                    "targets": [8],
                    "orderable": false,
                },
            ],
        });
        $('body').on('keyup', '#capitalPriceInput', function(e) {
            currencyFormatRupiah(this)
        })
        $('body').on('click', '#generateBarcode', function(e) {
            generateProductBarcode()
        })
        // Crud
        // Insert / Update
        loadCategory()
        loadUnit()

        $('#productModal').on('shown.bs.modal', function(e) {
            generateProductBarcode()

            let button = $(e.relatedTarget)
            let trParents = button.parents().parents().closest('tr')
            let modal = $(this)
            let mode = button.data('mode')
            let barcode = trParents.find('td:eq(1)').text()
            let name = trParents.find('td:eq(2)').text()

            let h_modal = trParents.find('td:eq(5)').text().split('Rp.')
            let jual = trParents.find('td:eq(6)').text().split('Rp.')
            let id = button.data('id')

            let satuan = $(button).data('product_units_id')
            let kategori = $(button).data('product_categories_id')
            let information = $(button).data('information')

            modal.find('#productNameInput').focus()

            if (mode == 'edit') {
                modal.find('.modal-title').html(`Edit Produk : <b>${name}</b>`)
                $('#productForm').attr('action', `<?= base_url() ?>products/lists/edit/${id}`)
                modal.find('#barcodeInput').val(barcode)
                modal.find('#productNameInput').val(name)
                modal.find('#capitalPriceInput').val(h_modal[1])
                modal.find('#sellingPriceInput').val(jual[1])

                modal.find('#categoryIdInput').val(kategori).trigger('change')
                modal.find('#unitProductInput').val(satuan).trigger('change')
                modal.find('#informationInput').val(information).trigger('change')
                modal.find('#submitProduct').attr('class', 'btn btn-warning')
                modal.find('#submitProduct').html(`<i class="fa fa-edit"></i> Update`)
            } else {
                modal.find('.modal-title').text('Tambah Produk')
                $('#productForm').attr('action', '<?= base_url() ?>products/lists/store')
                modal.find('#barcodeInput').val('')
                modal.find('#productNameInput').val('')
                modal.find('#capitalPriceInput').val('')
                modal.find('#sellingPriceInput').val('')
                modal.find('#categoryIdInput').val('').trigger('change')
                modal.find('#unitProductInput').val('').trigger('change')
                modal.find('#informationInput').val('')
                modal.find('#submitProduct').attr('class', 'btn btn-primary')
                modal.find('#submitProduct').html(`<i class="fa fa-check-circle"></i> Simpan`)
            }
        })

        $('#importForm').validate({
            rules: {
                file: {
                    required: true,
                }
            },
            messages: {
                file: {
                    required: 'File belum dipilih!',
                }
            }
        })

        $('#productForm').validate({
            rules: {
                barcodeInput: {
                    required: true
                },
                productNameInput: {
                    required: true
                },
                capitalPriceInput: {
                    required: true
                },
                sellingPriceInput: {
                    required: true
                },
                categoryIdInput: {
                    required: true
                },
                unitProductInput: {
                    required: true
                },
                informationInput: {
                    required: true
                },
            },
            messages: {
                barcodeInput: {
                    required: "Barcode harus diisi"
                },
                productNameInput: {
                    required: "Nama harus diisi"
                },
                capitalPriceInput: {
                    required: "Harga modal harus diisi"
                },
                sellingPriceInput: {
                    required: "Harga jual harus diisi"
                },
                categoryIdInput: {
                    required: "Kategori harus diisi"
                },
                unitProductInput: {
                    required: "Satuan harus diisi"
                },
            },
            errorPlacement: function (error, element) {
                if (element.parent().hasClass('input-group')) {
                    error.insertAfter(element.parent())
                } else {
                    error.insertAfter(element)
                }
            },
            highlight: function (element, errorClasss) {
                $(element).removeClass(errorClasss)
            },
        })

        function checkPrice(value) {
            if (typeof value == "string") {
                let final = 0;
                for (let i = 0; i < value.length; i++) {
                    if (value[i] != "." && value[i] != ",") {
                        final = (final * 10) + parseInt(value[i]);
                    }
                }
                return final;
            } else {
                return value;
            }
        }
        $(document).on('submit', '#productForm', function(e) {
            e.preventDefault()
            let action = $(this).attr('action')
            $.ajax({
                url: action,    
                type: 'POST',
                data: $('#productForm').serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.status == true) {
                        $('#productModal').modal('hide')
                        setTimeout(() => {
                            swal({
                                title: "Berhasil!",
                                text: response.message,
                                icon: "success",
                            }).then(function() {
                                tableProduct.ajax.reload();
                            });
                        }, 350)
                    }
                }
            })
        })

        $('#importForm').on('submit', function (e) {
            e.preventDefault()
            let action = $(this).attr('action')
            $.ajax({
                url: action,    
                type: 'POST',
                enctype: 'multipart/form-data',
                data: new FormData(this),
                processData:false,
                contentType:false,
                cache:false,
                async:false,
                success: function(response) {
                    const result = JSON.parse(response)
                    if (result.status == true) {
                        $('#importModal').modal('hide')
                        setTimeout(() => {
                            swal({
                                title: "Berhasil!",
                                text: result.message,
                                icon: "success",
                            }).then(function() {
                                tableProduct.ajax.reload();
                            });
                        }, 350)
                    } else {
                        $('#importModal').modal('hide')
                        setTimeout(() => {
                            swal({
                                title: "Gagal!",
                                text: result.message,
                                icon: "error",
                            }).then(function() {
                                tableProduct.ajax.reload();
                            });
                        }, 350)
                    }
                }
            })
        })

        $(document).on('click', '.product_stocks', function () {
            let id = $(this).data('id')
            window.location.href = `<?= base_url() ?>products/stocks/details/${id}`
        })
    })
</script>