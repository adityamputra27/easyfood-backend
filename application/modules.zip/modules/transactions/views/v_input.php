<?php $this->load->view('layouts/v_header') ?>
<section class="content-header">
    <h1>
        Transaksi Penjualan
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-shopping-cart"></i> Transaksi</a></li>
        <li class="active">Penjualan</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-9">
                            <div class="form-group row">
                                <label for="" class="col-sm-1 col-form-label">Barcode</label>
                                <div class="col-sm-2">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="barcode" autocomplete="off" readonly>
                                        <input type="hidden" class="form-control" id="stock_ins_id">
                                        <input type="hidden" class="form-control" id="products_id">
                                        <input type="hidden" class="form-control" id="products_name">
                                        <input type="hidden" class="form-control" id="first_price">

                                        <span class="input-group-btn">
                                            <button type="button" id="searchProduct" class="btn btn-info btn-flat"><i class="fa fa-search"></i></button>
                                        </span>
                                    </div>
                                </div>
                                <label for="" class="col-sm-8 col-form-label" style="padding: 5px;"><span class="productName"></span></label>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-sm-1 col-form-label">Quantity</label>
                                <div class="col-sm-2">
                                    <input type="number" class="form-control text-center" id="quantity" name="quantity" autocomplete="off" placeholder="0" min="0" disabled>
                                </div>
                                <label for="" class="col-sm-8 col-form-label" style="padding: 5px;"><span class="maxQuantity"></span></label>
                            </div>
                            <div class="form-group row">
                                <label for="" class="col-sm-1 col-form-label">Satuan</label>
                                <div class="col-sm-2">
                                    <input type="text" class="form-control text-center" id="unit" name="unit" autocomplete="off" disabled>
                                </div>
                            </div>
                            <div class="btn-transactions">
                                <button tabindex="3" class="btn btn-primary" type="button" id="addTransaction"><i class="fa fa-plus"></i> Tambah</button>&nbsp;
                                <button tabindex="4" class="btn btn-primary" type="button" id="btn_payment"><i class="fa fa-floppy-o"></i> Bayar</button>&nbsp;
                                <button tabindex="5" class="btn btn-info" type="button" onclick="location.reload()"><i class="fa fa-file-o"></i> Transaksi Baru</button>&nbsp;
                                <button tabindex="6" class="btn btn-warning" type="button" id="btn_hold"><i class="fa fa-hand-paper-o"></i> Hold</button>&nbsp;
                                <button tabindex="7" class="btn btn-default" type="button" id="btn_hold_list" data-toggle="modal" data-target="#TransactionHoldModal"><i class="fa fa-list-alt"></i> Hold List</button>&nbsp;
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div style="display: flex; justify-content: end;">
                                <label for="" style="padding-top: 5px;">Nota :</label>
                                <input type="text" class="text-bold text-right" readonly style="width: 145px; font-size: 17px; background-color: rgba(0,0,0,0) !important; border: 0 !important;" id="invoice" name="invoice" value="<?= $prefixInvoice ?>">
                            </div>
                            <p style="font-size: 60px; display: flex; justify-content: end;"><b>Rp. </b><b id="totalPrice"> 0</b></p>
                            <input type="hidden" id="total_bayar">
                        </div>
                    </div>
                    <table id="productTransaction" class="table table-bordered table-striped" style="margin-top: 2em;">
                        <thead class="text-center">
                            <tr>
                                <th width="10px" class="text-center">No</th>
                                <th width="400px;">Nama</th>
                                <th width="100px">Satuan</th>
                                <th width="170px;">Harga</th>
                                <th width="80px;">Quantity</th>
                                <th width="170px;">Diskon</th>
                                <th width="170px;">Total</th>
                                <th width='50px' class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td colspan="8">Tidak ada item produk!</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="searchProductModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Daftar Produk</h4>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table id="tableSearchProduct" class="table table-bordered table-striped table-hovered">
                            <thead>
                                <tr class="text-center">
                                    <th>No</th>
                                    <th>Barcode</th>
                                    <th>Nama</th>
                                    <th>Satuan</th>
                                    <th>Harga</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times-circle"></i> Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="TransactionHoldModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Daftar Hold Transaksi</h4>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table id="tableTransactionHold" class="table table-bordered table-striped table-hovered" width="100%">
                            <thead>
                                <tr class="text-center">
                                    <th width="1%">No</th>
                                    <th width="5%">Nota</th>
                                    <th>Tanggal</th>
                                    <th>Nama Produk</th>
                                    <th class="text-center">Total</th>
                                    <th class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times-circle"></i> Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="payModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Form Bayar</h4>
                </div>
                <form action="<?= base_url() ?>transactions/input/store" method="POST" id="payForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label for="" class="col-sm-4 col-form-label">Tanggal <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <div class="input-group date">
                                            <input type="text" class="form-control datepicker" autocomplete="off" name="date_modal" id="date_modal" data-provide="datepicker" value="   <?= date('Y-m-d  H:i:s') ?>">
                                            <div class="input-group-addon">
                                                <span class="fa fa-calendar"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-sm-4 col-form-label">Nota</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="nota" name="nota" disabled>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-sm-4 col-form-label">Jumlah Bayar <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <div class="input-group-addon">Rp</div>
                                            <input type="text" class="form-control total_cash" name="total_cash" pattern="[0-9]+" placeholder="0" id="totalCash" placeholder="0" autocomplete="off">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label for="" class="col-sm-4 col-form-label">Total Bayar</label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <div class="input-group-addon">Rp</div>
                                            <input type="text" class="form-control" name="total_bayar_modal" id="total_bayar_modal" disabled>
                                            <input type="hidden" id="total_bayar_modal_val">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-sm-4 col-form-label">Total Diskon</label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <div class="input-group-addon">Rp</div>
                                            <input type="text" class="form-control" name="diskon_modal" id="diskon_modal" disabled placeholder="0">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-sm-4 col-form-label">Keterangan</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="description">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <p style="font-size: 25px; justify-content: start; float:left">Kembalian Rp. <b id="kembalian_text" style="font-size: 30px;"> 0</b></p>
                                <input type="hidden" name="total_change">
                            </div>
                            <div class=" col-md-6">
                                <p style="font-size: 25px; justify-content: end; float:right">Grand Total Rp. <b id="total_bayar_modal_text" style="font-size: 30px;"> 0</b></p>
                            </div>
                        </div>
                    </div>
                    <div class=" modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal"><i class="fa fa-times-circle"></i> Tutup</button>
                        <button type="button" class="btn btn-success pull-right" id="Payment"><i class="fa fa-money"></i> Bayar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="successModal">
        <div class="modal-dialog modal-sm modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" id="btn-selesai" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="modal-title">Transaksi Berhasil</h4>
                </div>
                <div class="modal-body">
                    <div class="text-center">
                        <img src="<?= base_url() ?>assets/gif/success_trans.gif" width="200px" height="150px">
                    </div>
                </div>
                <div class="modal-footer text-center">
                    <div class="btn-group">
                        <a href="#" target="_blank" class="btn btn-default" id="printInvoice"><i class="fa fa-file-pdf-o"></i> Cetak Invoice</a>
                        <button type="button" class="btn btn-primary" id="btn-finish"><i class="fa fa-check-circle"></i> Selesai</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $this->load->view('layouts/v_footer') ?>
<script>
    $(function() {

        let productId = 0

        let tableSearchProduct = $('#tableSearchProduct').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Indonesian.json"
            },
            "processing": true,
            "serverSide": true,
            "order": [],
            "ajax": {
                "url": "<?= base_url() ?>products/lists/getSearchProduct",
                "type": "POST"
            },
            "columnDefs": [{
                "targets": [0],
                "orderable": false,
            }, ],
        });

        let tableTransactionHold = $('#tableTransactionHold').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Indonesian.json"
            },
            "processing": true,
            "serverSide": true,
            "order": [],
            "ajax": {
                "url": "<?= base_url() ?>transactions/input/getTransactionHold",
                "type": "POST"
            },
            "columnDefs": [{
                "targets": 0,
                "orderable": false,
            }, {
                "targets": 1,
                "orderable": false,
            }, {
                "targets": 2,
                "orderable": false,
            }, {
                "targets": 3,
                "orderable": false,
            }, {
                "targets": 4,
                "className": 'text-right',
                "orderable": false,
            }, {
                "targets": 5,
                "className": 'text-right',
                "orderable": false,
            }, ],
        });

        let datepicker = $.fn.datepicker.noConflict();
        $.fn.bootstrapDP = datepicker;
        $(".datepicker").bootstrapDP({
            autoclose: true,
            language: 'id',
            format: "   yyyy-mm-dd  <?= date('H:i:s') ?>"
        });

        function sweetalert(title, text, icon) {
            swal({
                title: title,
                text: text,
                icon: icon,
            })
        }

        function checkPrice(value) {
            if (typeof value == "string") {
                let final = 0;
                for (let i = 0; i < value.length; i++) {
                    if (value[i] != "." && value[i] != ",") {
                        final = (final * 10) + parseInt(value[i]);
                    }
                }
                return final;
            } else {
                return value;
            }
        }

        function generateCurrency(angka, prefix) {
            var number_string = angka.replace(/[^,\d]/g, '').toString(),
                split = number_string.split(','),
                sisa = split[0].length % 3,
                rupiah = split[0].substr(0, sisa),
                ribuan = split[0].substr(sisa).match(/\d{3}/gi);

            if (ribuan) {
                separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
            }

            rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
            return prefix == undefined ? rupiah : (rupiah ? '' + rupiah : '');
        }

        function currencyFormatRupiah(elemValue) {
            return $(elemValue).val(generateCurrency($(elemValue).val(), 'Rp. '))
        }

        function checkQtyMax(elemenValue, max) {
            if (parseFloat($(elemenValue).val()) > parseFloat(max)) {
                sweetalert("Maaf!", 'Maaf anda melebihi batas stok', "error")
                return $(elemenValue).val(max)
            } else {
                return false
            }
        }

        function calcSubtotal(e) {
            let column = e.closest('tr').find('td')
            let price = column.find('#price').val()
            let qty = e.val()
            column.find('#subtotal').val(parseInt(price) * parseFloat(qty))
            column.find('.subtotal_text').text('Rp. ' + parseInt(parseInt(price) * parseFloat(qty)).toLocaleString())

            calcDiscount(column.find('#discount'))
            calcTotalPrice()
        }

        function calcDiscount(e) {
            let column = $(e).closest('tr').find('td')
            let discount = checkPrice($(e).val())
            let price = column.find('#price').val()
            let qty = column.find('#qtyChange').val()

            let calcDis = (price * qty) - discount;

            column.find('#discount').val(discount)
            column.find('#subtotal').val(calcDis)
            column.find('.subtotal_text').text('Rp. ' + parseInt(calcDis).toLocaleString())
            currencyFormatRupiah(e)
            calcTotalPrice()
        }

        function calcTotalPrice() {
            let totalPrice = 0
            $('input[name="subtotal[]"]').each(function() {
                totalPrice += parseInt($(this).val())
            })
            $('#totalPrice').text(parseInt(totalPrice).toLocaleString())
            $('#total_bayar').val(totalPrice)
        }

        function setFocusQuantity() {
            $('input[name="qty[]"]').each(function() {
                $(this).focus()
            })
        }

        function appendRow(stock_ins_id, products_id, unit, product_name, price, qty, qty_max, subtotal, discount = 0) {
            record = `<tr>
            <td>#<span class="id-product-field" hidden>${products_id}</span></td>
            <td>${product_name}</td>
            <td>${unit}</td>
            <td>Rp. ${ parseInt(price).toLocaleString() }</td>
            <td><input type="number" class="form-control form-control-sm" id="qtyChange" autocomplete="off" placeholder="0" name="qty[]" value="${qty}" min="1" max="${qty_max}"></td>
            <td><input type="text" class="form-control form-control-sm" id="discountChange" autocomplete="off" pattern="[0-9]+" placeholder="0" value="${discount}"></td>
            <td><span class="subtotal_text">Rp. ${ parseInt(subtotal).toLocaleString() }</span></td>
            <td><button type="button" id="removeProductCart" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Hapus</button>

            <input type="hidden" name="stock_ins_id[]" value="${stock_ins_id}">
            <input type="hidden" name="products_id[]" value="${products_id}">
            <input type="hidden" name="price[]" id="price" value="${price}">
            <input type="hidden" name="discount[]" id="discount" value="${discount}">
            <input type="hidden" name="subtotal[]" id="subtotal" value="${subtotal}"></td>
            </tr>`;
            $('#productTransaction tbody').append(record)
        }

        $('#quantity').on('keyup change', function(e) {
            e.preventDefault()
            checkQtyMax(this, $(this).attr('max'))
            if (e.keyCode == 13) {
                $('#addTransaction').trigger('click')
            }
        })

        $('.total_cash').on('keyup change', function (e) {
            e.preventDefault()
            if (e.keyCode == 13) {
                $('#Payment').trigger('click')
            }
        })

        $(document).on('keyup change', '#discountChange', function(e) {
            e.preventDefault()
            calcDiscount(this)
        })

        $(document).on('keyup change', '#qtyChange', function(e) {
            e.preventDefault()
            checkQtyMax(this, $(this).attr('max'))
            calcSubtotal($(this))
        })

        $(document).on('keyup', '#totalCash', function(e) {
            currencyFormatRupiah(this)
        })

        $('#searchProduct').on('click', function(e) {
            e.preventDefault()
            $('#searchProductModal').modal('show')
        })

        $('body').on('click', '#selectProduct', function() {
            let check_product = $('.id-product-field:contains(' + $(this).data('idproduct') + ')').length;
            if (check_product == 1) {
                $('#searchProductModal').modal('hide')
                sweetalert("Maaf!", 'Produk yang anda pilih sudah ada dalam list!', "error")
            } else {
                $.ajax({
                    url: `<?= base_url() ?>transactions/input/getProductExpiredDate/${$(this).data('idproduct')}`,
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        if (response?.data?.total == 0 || response.data == null) {
                            sweetalert("Stok habis!", 'Stok pada barang ini sudah habis!', "error")
                        } else {
                            $('#barcode').val(response.data.barcode)
                            $('#products_name').text(response.data.name)
                            $('.productName').text(response.data.name)
                            $('#stock_ins_id').val(response.data.id)
                            $('#products_id').val(response.data.products_id)
                            $('#first_price').val(response.data.selling_price)
                            $('#unit').val(response.data.unit_name)

                            $('#quantity').val('')
                            $('#quantity').attr('disabled', false)
                            $('#quantity').attr('max', response.data.total)

                            $('.maxQuantity').text(`Maks. Stok : ${response.data.total} (${response.data.unit_name})`)
                            $('#searchProductModal').modal('hide')
                        }
                    }
                })
            }
        })

        $('#addTransaction').on('click', function() {
            $('#quantity').attr('disabled', true)
            if ($('#barcode').val().length == '') {
                sweetalert("Maaf!", 'Mohon input barcode terlebih dahulu!', "error")
            } else if ($('#quantity').val().length == '') {
                $('#quantity').attr('disabled', false)
                sweetalert("Maaf!", 'Mohon input quantity terlebih dahulu!', "error")
            } else {
                let productName = $('#products_name').text()
                let stocksInId = $('#stock_ins_id').val()
                let productsId = $('#products_id').val()
                let price = $('#first_price').val()
                let quantity = $('#quantity').val()
                let unit = $('#unit').val()
                let quantity_max = $('#quantity').attr('max')
                let subtotal = parseInt(price) * parseFloat(quantity)

                let tbody = $('#productTransaction tbody tr td').text();
                if (tbody == 'Tidak ada item produk!') {
                    $('#productTransaction tbody tr').remove();
                }

                appendRow(stocksInId, productsId, unit, productName, price, quantity, quantity_max, subtotal)
                calcTotalPrice()
                setFocusQuantity()

                $('#barcode, #products_name, #unit, #products_id, #stock_ins_id, #first_price , #quantity').val('')
                $('.productName').text('')
                $('.maxQuantity').text('')
            }
        })

        $('body').on('click', '#removeProductCart', function(e) {
            $(this).closest('tr').remove()
            calcTotalPrice()
            if ($('#productTransaction tbody tr').length == 0) {
                $('#productTransaction tbody').append('<tr align="center"><td colspan="8">Tidak ada item produk!</td></tr>');
            }
        })

        $('body').on('click', '#btn_payment', function(e) {
            e.preventDefault()
            if ($('#productTransaction tbody tr td').text() == 'Tidak ada item produk!') {
                sweetalert("Maaf!", 'Pilih setidaknya 1 item terlebih dahulu', "error")
            } else {
                $('#payModal').modal('show')
            }
        })

        // Script for Modal Payment
        $('#payModal').on('show.bs.modal', function() {
            let nota = $('#invoice').val()
            let total_bayar = $('#total_bayar').val()
            let modal = $(this)
            calcDiscountAll()

            modal.find('.modal-body #total_bayar_modal').val(parseInt(total_bayar).toLocaleString())
            modal.find('.modal-body #total_bayar_modal_text').text(parseInt(total_bayar).toLocaleString())
            modal.find('.modal-body #total_bayar_modal_val').val(total_bayar)
            modal.find('.modal-body #nota').val(nota)
        })

        function calcDiscountAll() {
            let total = 0;
            $('input[name="discount[]"]').each(function() {
                total += parseInt(checkPrice($(this).val()))
            })
            $('#payModal #diskon_modal').val(parseInt(total).toLocaleString());
        }

        function calcKembalian() {
            let jumlah_bayar = checkPrice($('input[name="total_cash"]').val())
            let total_bayar = $('#total_bayar_modal_val').val()

            let kembalian = parseInt(jumlah_bayar) - parseInt(total_bayar)
            $('#kembalian_text').text(parseInt(kembalian).toLocaleString())
            $('input[name="total_change"]').val(kembalian)
        }

        $('input[name="total_cash"]').on('keyup', function(e) {
            e.preventDefault()
            calcKembalian()
        })

        // $('input[name="diskon_modal"]').on('keyup', function(e) {
        //     e.preventDefault()
        //     calcDiscountAll($(this))
        // })

        function pushArray(elemen, variable) {
            $(elemen).each(function() {
                variable.push($(this).val())
            })
        }

        //Script for Payment Proccess
        $('#Payment').on('click', function(e) {
            let invoice = $('#invoice').val()
            let transactions_date = $('#date_modal').val()
            let total = $('#total_bayar_modal_val').val()
            let discountAll = checkPrice($('input[name="diskon_modal"]').val())
            let pay = checkPrice($('input[name="total_cash"]').val())
            let totalChange = $('input[name="total_change"]').val()
            let totalCash = $('input[name="total_cash"]').val();
            let description = $('input[name="description"]').val()

            if (parseInt(pay) < parseInt(total)) {
                sweetalert('Maaf', 'Jumlah nominal pembayaran kurang!', 'error')
            } else {
                //data array
                let stock_ins_id = [];
                let products_id = [];
                let qty = [];
                let price = [];
                let discountEach = [];
                let subtotal = [];

                //pushData
                pushArray($('input[name="stock_ins_id[]"]'), stock_ins_id)
                pushArray($('input[name="products_id[]"]'), products_id)
                pushArray($('input[name="qty[]"]'), qty)
                pushArray($('input[name="price[]"]'), price)
                pushArray($('input[name="discount[]"]'), discountEach)
                pushArray($('input[name="subtotal[]"]'), subtotal)

                //makeBunddle
                let finalData = {
                    invoice: invoice,
                    transaction_date: transactions_date,
                    total: total,
                    discountAll: discountAll,
                    stock_ins_id: stock_ins_id,
                    products_id: products_id,
                    qty: qty,
                    price: price,
                    discountEach: discountEach,
                    subtotal: subtotal,
                    totalChange: totalChange,
                    totalCash: pay,
                    description: description
                };

                //insert
                $(this).attr('disabled', true)
                let action = $('#payModal #payForm').attr('action')
                $.ajax({
                    url: action,
                    method: 'POST',
                    data: finalData,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status == true) {
                            $(this).attr('disabled', false)
                            $('#payModal').modal('hide')
                            swal({
                                title: "Transaksi Berhasil!",
                                text: "Apakah Anda Ingin Cetak Struk?",
                                icon: "success",
                                buttons: true,
                            })
                            .then((confirmPrint) => {
                                if (confirmPrint) {
                                    window.open(`<?= base_url() ?>transactions/input/printInvoice/${response.data}`, '__blank')
                                    location.reload()
                                } else {
                                    location.reload()
                                }
                            });
                        }
                    }
                })
            }
        })


        $('body').on('click', '#btn_hold', function(e) {
            e.preventDefault()
            if ($('#productTransaction tbody tr td').text() == 'Tidak ada item produk!') {
                sweetalert("Maaf!", 'Tidak ada item produk untuk transaksi!', "error")
            } else {
                let invoice = $('#invoice').val()
                let transactions_date = $('#date_modal').val()
                let total_bayar = $('#total_bayar').val()

                //data array
                let stock_ins_id = [];
                let products_id = [];
                let qty = [];
                let price = [];
                let discountEach = [];
                let subtotal = [];

                //pushData
                pushArray($('input[name="stock_ins_id[]"]'), stock_ins_id)
                pushArray($('input[name="products_id[]"]'), products_id)
                pushArray($('input[name="qty[]"]'), qty)
                pushArray($('input[name="price[]"]'), price)
                pushArray($('input[name="discount[]"]'), discountEach)
                pushArray($('input[name="subtotal[]"]'), subtotal)

                //makeBunddle
                let finalData = {
                    invoice: invoice,
                    transaction_date: transactions_date,
                    total_bayar: total_bayar,
                    //table
                    products_id: products_id,
                    stock_ins_id: stock_ins_id,
                    qty: qty,
                    price: price,
                    discountEach: discountEach,
                    subtotal: subtotal,
                };

                //insert
                $(this).attr('disabled', true)
                $.ajax({
                    url: '<?= base_url() ?>transactions/input/hold',
                    method: 'POST',
                    data: finalData,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status == true) {
                            $(this).attr('disabled', false)
                            swal({
                                title: response.message,
                                icon: "success",
                            }).then(function() {
                                location.reload()
                            })
                        }
                    }
                })
            }
        })

        $(document).on('click', '#Proccess', function(e) {
            e.preventDefault()
            let id = $(this).data('id')
            $('#TransactionHoldModal').modal('hide')
            $('#btn_hold').attr('disabled', true)
            $.ajax({
                url: '<?= base_url() ?>transactions/input/proccess/' + id + '',
                method: 'POST',
                dataType: 'json',
                success: function(response) {
                    $('#productTransaction tbody tr').remove();
                    $('#invoice').val(response[0].invoice)
                    let transaction_details = response[0].transaction_details
                    transaction_details.forEach(element => {
                        let subtotal = (parseInt(element.price) * parseFloat(element.quantity)) - parseInt(element.discount)
                        appendRow(element.stock_ins_id, element.products_id, element.unit_name, element.name, element.price, element.quantity, element.stock, subtotal, element.discount)
                    });
                    calcTotalPrice()
                }
            })
        })

        $('body').on('click', '.delete-transaction-hold', function() {
            let trParents = $(this).parents().parents().closest('tr')
            let invoice = trParents.find('td:eq(1)').text()
            swal({
                    title: "Apakah kamu yakin?",
                    text: `Transaksi yang di hold : '${invoice}' akan dibatalkan?`,
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((confirmDelete) => {
                    if (confirmDelete) {
                        let id = $(this).attr('data-id')
                        console.log(id)
                        $.ajax({
                            url: `<?= base_url() ?>transactions/input/delete_hold/${id}`,
                            type: 'DELETE',
                            dataType: 'json',
                            success: function(response) {
                                if (response.status == true) {
                                    swal({
                                        title: "Berhasil!",
                                        text: response.message,
                                        icon: "success",
                                    }).then(function() {
                                        location.reload();
                                    });
                                } else {
                                    swal({
                                        title: "Gagal!",
                                        text: response.message,
                                        icon: "error",
                                    })
                                }
                            }
                        })
                    }
                });
        })

    })
</script>