<?php $this->load->view('layouts/v_header') ?>
<section class="content-header">
  <h1>
    Data Pengeluaran
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-shopping-cart"></i> Transaksi</a></li>
    <li class="active">Pengeluaran</li>
  </ol>
</section>

<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header">
          <div class="btn-group">
            <a href="#" class="btn btn-primary" id="showModal"><i class="fa fa-plus-circle"></i> Tambah</a>
            <a href="#" class="btn btn-warning" id="showModalRegister"><i class="fa fa-money"></i> Close Register</a>
          </div>
        </div>
        <div class="box-body">
          <table id="expenditure" class="table table-bordered table-striped" width="100%">
            <thead>
              <tr>
                <th width="10px" class="text-center">No</th>
                <th>Tanggal</th>
                <th>Jumlah</th>
                <th>Keterangan</th>
                <th width='125px' class="text-center">Aksi</th>
              </tr>
            </thead>
            <tbody>

            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
</section>
<div class="modal fade" id="expenditureModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="expenditureForm" method="POST">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title"></h4>
        </div>
        <div class="modal-body">

          <div class="form-group row">
            <label for="" class="col-sm-3 col-form-label">Tanggal</label>
            <div class="col-sm-9">
                <div class="input-group date">
                    <input type="datetime-local" name="date" class="form-control" id="datepicker">
                </div>
            </div>
          </div>

          <div class="form-group row">
            <label for="" class="col-sm-3 col-form-label">Jumlah</label>
            <div class="col-sm-9">
              <div class="input-group">
                <div class="input-group-addon">Rp.</div>
                <input type="text" class="form-control" name="total" id="capitalPriceInput" placeholder="0" autocomplete="off">
              </div>
            </div>
          </div>

          <div class="form-group row">
            <label for="" class="col-sm-3 col-form-label">Keterangan </label>
            <div class="col-sm-9">
              <textarea name="description" id="description" class="form-control" autocomplete="off"></textarea>
            </div>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal"><i class="fa fa-times-circle"></i> Tutup</button>
          <button type="submit" class="btn btn-primary" id="submitExpenditure"><i class="fa fa-check-circle"></i> Simpan</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<?php $this->load->view('layouts/v_footer') ?>
<script>
  $(function() {
    $('#ExpenditureModal').on('keypress', function(e) {
      // console.log(e.which)
      if (e.which == 13) {
        return false
      }
    })
    let tableExpenditure = $('#expenditure').DataTable({
      "language": {
        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Indonesian.json"
      },
      "processing": true,
      "serverSide": true,
      "order": [],
      "ajax": {
        "url": "<?= base_url() ?>transactions/expenditure/getExpenditure",
        "type": "POST"
      },
      "columnDefs": [{
          "targets": [0],
          "orderable": false,
        },
        {
          "targets": [4],
          "orderable": false,
        },
      ],
    });

    let config = {
        enableTime: true,
        dateFormat: "d-m-Y H:i"
    }
    const fp = flatpickr("#datepicker", config)

    function generateCurrency(angka, prefix) {
      var number_string = angka.replace(/[^,\d]/g, '').toString(),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);

      if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
      }

      rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
      return prefix == undefined ? rupiah : (rupiah ? '' + rupiah : '');
    }

    function currencyFormatRupiah(elemValue) {
      return $(elemValue).val(generateCurrency($(elemValue).val(), 'Rp. '))
    }

    $(document).on('keyup', '#capitalPriceInput', function(e) {
      currencyFormatRupiah(this)
    })
    $('#showModalRegister').on('click', function(e) {
      $('#expenditureModal').modal('show')
      $('.modal-title').text('Close Register')
      $('#expenditureForm').attr('action', '<?= base_url() ?>transactions/expenditure/store')
      $('#submitExpenditure').attr('class', 'btn btn-primary')
      $('#submitExpenditure').removeAttr('disabled')
      $('#submitExpenditure').html(`<i class="fa fa-check-circle"></i> Simpan`)

      $('.modal-body #date').val('');
      $('.modal-body #capitalPriceInput').val('');
      $('.modal-body #description').val('Close Register');
    })
    $('#showModal').on('click', function(e) {

      $('#expenditureModal').modal('show')

      $('.modal-title').text('Tambah Pengeluaran')
      $('#expenditureForm').attr('action', '<?= base_url() ?>transactions/expenditure/store')
      $('#submitExpenditure').attr('class', 'btn btn-primary')
      $('#submitExpenditure').removeAttr('disabled')
      $('#submitExpenditure').html(`<i class="fa fa-check-circle"></i> Simpan`)

      $('.modal-body #date').val('');
      $('.modal-body #capitalPriceInput').val('');
      $('.modal-body #description').val('');
    })
    $('body').on('click', '.btn-edit', function(e) {
      $('#expenditureModal').modal('show')
      let trParents = $(this).closest('tr')
      let id = $(this).attr('data-id')
      let date = $(this).attr('data-date')
      let total = trParents.find('td:eq(2)').text().split('Rp.')
      let description = trParents.find('td:eq(3)').text()

      fp.setDate(date, true)

      $('.modal-title').html(`Edit Pengeluaran Tanggal : <b>${date}</b>`)
      $('#expenditureForm').attr('action', `<?= base_url() ?>transactions/expenditure/edit/${id}`)
      $('.modal-body #capitalPriceInput').val(total[1]);
      $('.modal-body #description').val(description);
      $('#submitExpenditure').attr('class', 'btn btn-warning')
      $('#submitExpenditure').html(`<i class="fa fa-edit"></i> Update`)
    })

    $('#expenditureForm').validate({
      rules: {
        date: {
            required: true
        },
        total: {
            required: true
        },
        description: {
            required: true
        },
      },
      messages: {
        date: {
            required: "Tanggal harus diisi"
        },
        total: {
            required: "Jumlah harus diisi"
        },
        description: {
            required: "Keterangan harus diisi"
        }
      },
      errorPlacement: function (error, element) {
          if (element.parent().hasClass('input-group')) {
              error.insertAfter(element.parent())
          } else {
              error.insertAfter(element)
          }
      },
      highlight: function (element, errorClasss) {
          $(element).removeClass(errorClasss)
      },
    })

    $(document).on('submit', '#expenditureForm', function(e) {
      e.preventDefault()
      
      let action = $(this).attr('action')
      $.ajax({
        url: action,
        method: 'POST',
        data: $('#expenditureForm').serialize(),
        dataType: 'json',
        cache: false,
        success: function(response) {
          if (response.status == true) {
            $('#expenditureModal').modal('hide')
            swal({
              title: "Berhasil!",
              text: response.message,
              icon: "success",
            }).then(function() {
              tableExpenditure.ajax.reload();
            });
          }
        }
      })
    })
    // Delete
    $('body').on('click', '.delete-expenditure', function() {
      let trParents = $(this).parents().parents().closest('tr')
      let date = trParents.find('td:eq(1)').text()
      swal({
          title: "Apakah kamu yakin?",
          text: `Data pengeluaran tanggal ${date} akan dihapus?`,
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((confirmDelete) => {
          if (confirmDelete) {
            let id = $(this).attr('data-id')
            $.ajax({
              url: `<?= base_url() ?>transactions/expenditure/delete/${id}`,
              type: 'DELETE',
              dataType: 'json',
              success: function(response) {
                if (response.status == true) {
                  swal({
                    title: "Berhasil!",
                    text: response.message,
                    icon: "success",
                  }).then(function() {
                    tableExpenditure.ajax.reload();
                  });
                } else {
                  swal({
                    title: "Gagal!",
                    text: response.message,
                    icon: "error",
                  })
                }
              }
            })
          }
        });
    })

  })
</script>