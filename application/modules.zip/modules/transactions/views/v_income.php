<?php $this->load->view('layouts/v_header') ?>
<section class="content-header">
  <h1>
    Data Pemasukan
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-shopping-cart"></i> Transaksi</a></li>
    <li class="active">Pemasukan</li>
  </ol>
</section>

<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header">
          <div class="btn-group">
            <a href="#" class="btn btn-primary" id="showIncomeModal"><i class="fa fa-plus-circle"></i> Tambah</a>
            <a href="#" class="btn btn-warning" id="showOpenIncomeModal"><i class="fa fa-money"></i> Open Register</a>
          </div>
        </div>
        <div class="box-body">
          <table id="income" class="table table-bordered table-striped" width="100%">
            <thead>
              <tr>
                <th width="10px" class="text-center">No</th>
                <th>Tanggal</th>
                <th>Jumlah</th>
                <th>Keterangan</th>
              </tr>
            </thead>
            <tbody>

            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
</section>
<div class="modal fade" id="incomeModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?= base_url() ?>transactions/income/store" id="incomeForm" method="POST">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Tambah Pemasukan</h4>
        </div>
        <div class="modal-body">

          <div class="form-group row">
            <label for="" class="col-sm-3 col-form-label">Tanggal</label>
            <div class="col-sm-9">
                <div class="input-group date">
                    <input type="datetime-local" name="date" class="form-control" id="datepicker">
                </div>
            </div>
          </div>
          <div class="form-group row">
            <label for="" class="col-sm-3 col-form-label">Jumlah</label>
            <div class="col-sm-9">
              <div class="input-group">
                <div class="input-group-addon">Rp.</div>
                <input type="text" class="form-control" name="total" id="capitalPriceInput" placeholder="0" autocomplete="off">
              </div>
            </div>
          </div>

          <div class="form-group row">
            <label for="" class="col-sm-3 col-form-label">Keterangan </label>
            <div class="col-sm-9">
              <textarea name="description" id="description" class="form-control" autocomplete="off"></textarea>
            </div>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal"><i class="fa fa-times-circle"></i> Tutup</button>
          <button type="submit" class="btn btn-primary" id="submitIncome"><i class="fa fa-check-circle"></i> Simpan</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<?php $this->load->view('layouts/v_footer') ?>
<script>
  $(function() {
    $('#incomeModal').on('keypress', function(e) {
      // console.log(e.which)
      if (e.which == 13) {
        return false
      }
    })
    let tableIncome = $('#income').DataTable({
      "language": {
        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Indonesian.json"
      },
      "processing": true,
      "serverSide": true,
      "order": [],
      "ajax": {
        "url": "<?= base_url() ?>transactions/income/getIncome",
        "type": "POST"
      },
      "columnDefs": [{
        "targets": [0],
        "orderable": false,
      }, ],
    });

    let config = {
        enableTime: true,
        dateFormat: "d-m-Y H:i"
    }
    const fp = flatpickr("#datepicker", config)

    function generateCurrency(angka, prefix) {
      var number_string = angka.replace(/[^,\d]/g, '').toString(),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);

      if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
      }

      rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
      return prefix == undefined ? rupiah : (rupiah ? '' + rupiah : '');
    }

    function currencyFormatRupiah(elemValue) {
      return $(elemValue).val(generateCurrency($(elemValue).val(), 'Rp. '))
    }

    $(document).on('keyup', '#capitalPriceInput', function(e) {
      currencyFormatRupiah(this)
    })

    $('#showOpenIncomeModal').on('click', function(e) {
      $('#incomeModal').modal('show')
      
      $('.modal-title').text('Open Register')
      $('.modal-body #date').val('');
      $('#incomeForm').trigger('reset')
      $('#description').val('Open Register')
      $('#submitIncome').attr('class', 'btn btn-primary')
      $('#submitIncome').html(`<i class="fa fa-check-circle"></i> Simpan`)
    })

    $('#showIncomeModal').on('click', function(e) {
      $('#incomeModal').modal('show')

      $('.modal-title').text('Tambah Pemasukkan')
      $('.modal-body #date').val('');
      $('#incomeForm').trigger('reset')
      $('#submitIncome').attr('class', 'btn btn-primary')
      $('#submitIncome').html(`<i class="fa fa-check-circle"></i> Simpan`)
      modal.find('#submitIncome').attr('class', 'btn btn-primary')
      modal.find('#submitIncome').html(`<i class="fa fa-check-circle"></i> Simpan`)
    })

    $('#incomeForm').validate({
      rules: {
        date: {
            required: true
        },
        total: {
            required: true
        },
        description: {
            required: true
        },
      },
      messages: {
        date: {
            required: "Tanggal harus diisi"
        },
        total: {
            required: "Jumlah harus diisi"
        },
        description: {
            required: "Keterangan harus diisi"
        }
      },
      errorPlacement: function (error, element) {
          if (element.parent().hasClass('input-group')) {
              error.insertAfter(element.parent())
          } else {
              error.insertAfter(element)
          }
      },
      highlight: function (element, errorClasss) {
          $(element).removeClass(errorClasss)
      },
    })

    $(document).on('submit', '#incomeForm', function(e) {
      e.preventDefault()

      let action = $(this).attr('action')
      $.ajax({
        url: action,
        type: 'POST',
        data: $('#incomeForm').serialize(),
        dataType: 'json',
        success: function(response) {
          if (response.status == true) {
            $('#incomeModal').modal('hide')
            swal({
              title: "Berhasil!",
              text: response.message,
              icon: "success",
            }).then(function() {
              tableIncome.ajax.reload();
            });
          }
        }
      })
    })

  })
</script>