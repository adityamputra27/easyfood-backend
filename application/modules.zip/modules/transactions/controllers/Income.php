<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Income extends CI_Controller
{

 public function __construct()
 {
  parent::__construct();
  $this->load->database();
  $this->load->model('sistem_model');
  $this->load->model('income_model');
  $this->load->library('encryption');
  $this->load->helper('url');
  $this->loginCheck();
 }

 public function index()
 {
  $this->load->view('v_income');
 }

 public function store()
 {
  $data = [
   'date' => date('Y-m-d H:i', strtotime($this->input->post('date'))).':'.date('s'),
   'total' => parent::checkPrice($this->input->post('total')),
   'description' => $this->input->post('description'),
   'users_id' => $this->session->userdata('users_id'),
   'updated_at' => date('Y-m-d H:i:s'),
   'created_at' => date('Y-m-d H:i:s')
  ];
  $this->sistem_model->_input('incomes', $data);

  $response['status'] = true;
  $response['message'] = 'Data Pemasukan Berhasil Di Tambahkan!';
  $response['data'] = $data;

  echo json_encode($response);
 }

 public function getIncome()
 {
  $list = $this->income_model->_getDatatables();
  $data = array();
  $no = $_POST['start'];
  $draw = $_POST['draw'];

  foreach ($list as $value) {
   $no++;
   $row = array();
   $row[] = $no;
   $row[] = $value->date;
   $row[] = 'Rp. ' . number_format($value->total, 0, '.', '.');
   $row[] = $value->description;
   $data[] = $row;
  }

  $output = [
   'draw' => $draw,
   'recordsTotal' => $this->income_model->_countAll(),
   'recordsFiltered' => $this->income_model->_countFiltered(),
   'data' => $data
  ];

  echo json_encode($output);
 }
}
