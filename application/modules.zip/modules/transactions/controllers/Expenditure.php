<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Expenditure extends CI_Controller
{

   public function __construct()
   {
      parent::__construct();
      $this->load->database();
      $this->load->model('sistem_model');
      $this->load->model('expenditure_model');
      $this->load->library('encryption');
      $this->load->helper('url');
      $this->loginCheck();
   }

   public function index()
   {
      $this->load->view('v_expenditure');
   }

   public function store()
   {
      $data = [
         'date' => date('Y-m-d H:i', strtotime($this->input->post('date'))).':'.date('s'),
         'total' => parent::checkPrice($this->input->post('total')),
         'description' => $this->input->post('description'),
         'users_id' => $this->session->userdata('users_id'),
         'updated_at' => date('Y-m-d H:i:s'),
         'created_at' => date('Y-m-d H:i:s')
      ];
      $this->sistem_model->_input('expenditures', $data);

      $response['status'] = true;
      $response['message'] = 'Data Pengeluaran Berhasil Di Tambahkan!';
      $response['data'] = $data;

      echo json_encode($response);
   }

   public function edit($id)
   {
      $check = $this->sistem_model->_get_where_id('expenditures', array('MD5(id)' => $id));

      if (count($check) > 0) {
         $data = [
            'date' => $this->input->post('date'),
            'total' => parent::checkPrice($this->input->post('total')),
            'description' => $this->input->post('description'),
            'users_id' => $this->session->userdata('users_id'),
            'updated_at' => date('Y-m-d H:i:s')
         ];

         $this->sistem_model->_update('expenditures', $data, array('MD5(id)' => $id));
         $response['status'] = true;
         $response['message'] = 'Data Pengeluaran Berhasil Di Update!';
         $response['data'] = null;
      } else {
         $response['status'] = false;
         $response['message'] = 'ID Pengeluaran Tidak Ditemukan!';
         $response['data'] = null;
      }

      echo json_encode($response);
   }

   public function delete($id)
   {
      $check = $this->sistem_model->_get_where_id('expenditures', array('MD5(id)' => $id));

      if (count($check) > 0) {
         $this->sistem_model->_delete('expenditures', array('MD5(id)' => $id));
         $response['status'] = true;
         $response['message'] = 'Data Pengeluaran Berhasil Di Hapus!';
         $response['data'] = null;
      } else {
         $response['status'] = false;
         $response['message'] = 'ID Pengeluaran Tidak Ditemukan!';
         $response['data'] = null;
      }

      echo json_encode($response);
   }

   public function getExpenditure()
   {
      $list = $this->expenditure_model->_getDatatables();
      $data = array();
      $no = $_POST['start'];
      $draw = $_POST['draw'];

      foreach ($list as $value) {

         $id = MD5($value->id);
         $link = '<div class="btn-group"><button type="button" class="btn btn-warning btn-sm btn-edit" data-id="' . $id . '" data-date="'.date('d-m-Y H:i', strtotime($value->date)).'"><i class="fa fa-edit"></i> Edit</button><button type="button" class="btn btn-danger btn-sm delete-expenditure" data-id="' . $id . '"><i class="fa fa-trash"></i> Hapus</a></div>';

         $no++;
         $row = array();
         $row[] = $no;
         $row[] = $value->date;
         $row[] = 'Rp. ' . number_format($value->total, 0, '.', '.');
         $row[] = $value->description;
         $row[] = $link;
         $data[] = $row;
      }

      $output = [
         'draw' => $draw,
         'recordsTotal' => $this->expenditure_model->_countAll(),
         'recordsFiltered' => $this->expenditure_model->_countFiltered(),
         'data' => $data
      ];

      echo json_encode($output);
   }
}
